# =========================
# System Snapshot Script
# =========================

$pcName = $env:COMPUTERNAME
$scriptRoot = $PSScriptRoot
#$folderPath = Join-Path $scriptRoot "info\$pcName"
$snapshotFolderName = $env:SNAPSHOT_FOLDER
$folderPath = Join-Path (Join-Path $scriptRoot "info") $snapshotFolderName


if (-not (Test-Path -Path $folderPath)) {
    New-Item -Path $folderPath -ItemType Directory | Out-Null
}

Write-Host "Starting system snapshot collection..." -ForegroundColor Cyan

# Prepare step counter
$totalSteps = 15
$step = 1

function Write-Step {
    param (
        [string]$Message,
        [int]$Step,
        [int]$Total
    )
    Write-Host "[$Step/$Total] $Message" -ForegroundColor Cyan
}

# ----------------
Write-Step "Capturing system information..." $step $totalSteps
Get-ComputerInfo | Export-Clixml -Path "$folderPath\systemInfo.xml"
$step++

# ----------------
Write-Step "Capturing network configuration..." $step $totalSteps
$flatNetConfig = Get-NetIPConfiguration | ForEach-Object {
    [PSCustomObject]@{
        InterfaceAlias = $_.InterfaceAlias
        InterfaceIndex = $_.InterfaceIndex
        InterfaceDesc  = $_.InterfaceDescription
        IPv4Address    = ($_.IPv4Address.IPAddress -join ",")
        IPv6Address    = ($_.IPv6Address.IPAddress -join ",")
        IPv4Gateway    = ($_.IPv4DefaultGateway.NextHop)
        IPv6Gateway    = ($_.IPv6DefaultGateway.NextHop)
        DNSServers     = ($_.DNSServer.ServerAddresses -join ",")
    }
}
$flatNetConfig | Export-Clixml -Path "$folderPath\ipConfig.xml"
$step++

# ----------------
Write-Step "Capturing printer information..." $step $totalSteps
Get-Printer | Select-Object Name, PrinterStatus, PortName | Export-Clixml -Path "$folderPath\printers.xml"
$step++

# ----------------
Write-Step "Capturing network drives..." $step $totalSteps
Get-PSDrive -PSProvider FileSystem | Export-Clixml -Path "$folderPath\networkDrive.xml"
$step++

# ----------------
Write-Step "Capturing installed software list..." $step $totalSteps
Get-ItemProperty HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*, 
HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* |
Select-Object DisplayName, DisplayVersion, Publisher, InstallDate |
Where-Object DisplayName -ne $null |
Sort-Object DisplayName | Export-Clixml -Path "$folderPath\softwareList.xml"
$step++

# ----------------
Write-Step "Capturing disk information..." $step $totalSteps
Get-PSDrive -PSProvider FileSystem | Where-Object {$_.Used -gt 0} | Select-Object `
    Name, 
    @{Name="Used (GB)";Expression={[math]::round($_.Used / 1GB, 2)}}, 
    @{Name="Free (GB)";Expression={[math]::round($_.Free / 1GB, 2)}}, 
    @{Name="Total (GB)";Expression={[math]::round(($_.Used + $_.Free) / 1GB, 2)}} |
Export-Clixml -Path "$folderPath\diskInfo.xml"
$step++

# ----------------
Write-Step "Capturing Windows updates..." $step $totalSteps
Get-HotFix | Select-Object Description, HotFixID, InstalledOn | Export-Clixml -Path "$folderPath\windowsUpdates.xml"
$step++

# ----------------
Write-Step "Capturing environment variables..." $step $totalSteps
$envVars = Get-ChildItem Env: | ForEach-Object {
    [PSCustomObject]@{
        Name  = $_.Key
        Value = $_.Value
    }
}
$envVars | Export-Clixml -Path "$folderPath\environmentVariables.xml"
$step++

# ----------------
Write-Step "Capturing user accounts..." $step $totalSteps
Get-LocalUser | Select-Object Name, Enabled | Export-Clixml -Path "$folderPath\userAccounts.xml"
$step++

# ----------------
Write-Step "Capturing service information..." $step $totalSteps
Get-Service | Select-Object Name, Status, DisplayName | Export-Clixml -Path "$folderPath\services.xml"
$step++

# ----------------
Write-Step "Capturing running processes..." $step $totalSteps
Get-Process | Select-Object Id, Name, StartTime, Path | Export-Clixml -Path "$folderPath\Process.xml"
$step++

# ----------------
Write-Step "Capturing startup programs..." $step $totalSteps
Get-CimInstance -ClassName Win32_StartupCommand | Select-Object Name, Command | Export-Clixml -Path "$folderPath\startupPrograms.xml"
$step++

# ----------------
Write-Step "Capturing installed drivers..." $step $totalSteps
$pnpEntities = Get-CimInstance Win32_PnPEntity
$signedDrivers = Get-CimInstance Win32_PnPSignedDriver

$combined = foreach ($pnp in $pnpEntities) {
    $matchingDriver = $signedDrivers | Where-Object { $_.DeviceID -eq $pnp.PNPDeviceID }
    if ($matchingDriver) {
        [PSCustomObject]@{
            Name          = $pnp.Name
            Manufacturer  = $pnp.Manufacturer
            DeviceID      = $pnp.PNPDeviceID
            DriverVersion = $matchingDriver.DriverVersion
            DriverDate    = $matchingDriver.DriverDate
        }
    }
}
$combined | Export-Clixml -Path (Join-Path $folderPath "drivers.xml")
$step++

Write-Host "`n[$totalSteps/$totalSteps] All snapshot steps completed successfully!" -ForegroundColor Green
