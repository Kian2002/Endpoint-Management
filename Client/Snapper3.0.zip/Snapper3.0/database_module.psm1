# =========================
# Module: database_module.psm1
# =========================

$global:MySqlConnection = $null

function Open-MySqlConnection {
    param (
        [string]$ConnectionString,
        [string]$MySqlDll
    )

    if (-not $MySqlDll) {
        $MySqlDll = Join-Path -Path $PSScriptRoot -ChildPath "..\Connectors\MySql.Data.dll"
    }

    if (-not (Test-Path $MySqlDll)) {
        throw "MySQL Connector DLL not found at path: $MySqlDll"
    }

    # Load System.Threading.Tasks.Extensions if present (needed for .NET Core compatibility)
    $tasksDll = Join-Path -Path (Split-Path $MySqlDll) -ChildPath "System.Threading.Tasks.Extensions.dll"
    if (Test-Path $tasksDll) {
        try {
            Add-Type -Path $tasksDll
        } catch {
            Write-Host "Warning: Failed to load System.Threading.Tasks.Extensions.dll - $($_.Exception.Message)" -ForegroundColor Yellow
        }
    }

    try {
        if (-not ("MySql.Data.MySqlClient.MySqlConnection" -as [type])) {
            Add-Type -Path $MySqlDll
        }
    } catch {
        Write-Host "Warning: MySQL .NET types might already be loaded." -ForegroundColor Yellow
    }

    $global:MySqlConnection = New-Object MySql.Data.MySqlClient.MySqlConnection($ConnectionString)

    # Try to open connection; prompt again if fails
    $retryCount = 0
    while ($true) {
        try {
            $global:MySqlConnection.Open()
            Write-Host "Connected to MySQL database." -ForegroundColor Cyan
            break
        } catch {
            Write-Host "Failed to connect: $($_.Exception.Message)" -ForegroundColor Red

            if ($retryCount -ge 2) {
                Write-Host "Exceeded maximum retry attempts. Exiting." -ForegroundColor Red
                exit
            }

            $retryCount++
            $newPwd = Read-Host -AsSecureString "Please re-enter MySQL password"
            $Bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($newPwd)
            $plainPwd = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($Bstr)
            [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($Bstr)

            # Save new secure string to .sec file
            $securePath = Join-Path -Path $PSScriptRoot -ChildPath "..\db_pwd.sec"
            $newPwd | ConvertFrom-SecureString | Set-Content $securePath
            Write-Host "New password saved securely for future runs." -ForegroundColor Green

            # Update connection string
            $script:Global:MySQLConnectionString = "server=endpoint-snapshot-db.c9kgcu6yi7f2.us-east-2.rds.amazonaws.com;port=3306;uid=admin;pwd=$plainPwd;database=snapshot;"
            $global:MySqlConnection.ConnectionString = $script:Global:MySQLConnectionString
        }
    }
}

function Close-MySqlConnection {
    if ($global:MySqlConnection -ne $null) {
        $global:MySqlConnection.Close()
        Write-Host "Connection closed." -ForegroundColor Yellow
        $global:MySqlConnection = $null
    }
}

function Add-PCAsset {
    param (
        [string]$AssetTag
    )
    $cmd = $global:MySqlConnection.CreateCommand()
    $cmd.CommandText = "INSERT IGNORE INTO pc_asset (asset_tag) VALUES (@tag);"
    $cmd.Parameters.Add("@tag", [MySql.Data.MySqlClient.MySqlDbType]::VarChar).Value = $AssetTag
    try {
        $cmd.ExecuteNonQuery() | Out-Null
        Write-Host "Inserted: $AssetTag" -ForegroundColor Green
    } catch {
        Write-Host "Failed to insert $AssetTag : $_" -ForegroundColor Red
    }
}

function Get-PCId {
    param (
        [string]$AssetTag
    )
    $cmd = $global:MySqlConnection.CreateCommand()
    $cmd.CommandText = "SELECT pc_id FROM pc_asset WHERE asset_tag = @tag;"
    $cmd.Parameters.Add("@tag", [MySql.Data.MySqlClient.MySqlDbType]::VarChar).Value = $AssetTag
    return $cmd.ExecuteScalar()
}

function Add-ComparisonResult {
    param (
        [int]$PCId,
        [datetime]$SnapshotBefore,
        [datetime]$SnapshotAfter,
        [string]$ComparedBy
    )
    $cmd = $global:MySqlConnection.CreateCommand()
    $cmd.CommandText = @"
        INSERT INTO comparison_result (pc_id, snapshot_before_time, snapshot_after_time, compared_by)
        VALUES (@pcid, @before, @after, @by);
"@
    $cmd.Parameters.AddWithValue("@pcid", $PCId)
    $cmd.Parameters.AddWithValue("@before", $SnapshotBefore)
    $cmd.Parameters.AddWithValue("@after", $SnapshotAfter)
    $cmd.Parameters.AddWithValue("@by", $ComparedBy)
    try {
        $cmd.ExecuteNonQuery() | Out-Null
        Write-Host "Inserted comparison_result for PC ID $PCId" -ForegroundColor Green
    } catch {
        Write-Host "Failed to insert into comparison_result: $_" -ForegroundColor Red
    }
    $cmd2 = $global:MySqlConnection.CreateCommand()
    $cmd2.CommandText = "SELECT LAST_INSERT_ID();"
    return $cmd2.ExecuteScalar()
}

function Add-ComparisonComponent {
    param (
        [int]$ComparisonId,
        [string]$ComponentType,
        [string]$JsonFilePath
    )
    try {
        $jsonContent = Get-Content -Path $JsonFilePath -Raw
    } catch {
        Write-Host "Failed to read JSON file: $_" -ForegroundColor Red
        return
    }
    $cmd = $global:MySqlConnection.CreateCommand()
    $cmd.CommandText = @"
        INSERT INTO comparison_component (comparison_id, component_type, diff_json)
        VALUES (@cmp_id, @ctype, @json);
"@
    $cmd.Parameters.AddWithValue("@cmp_id", $ComparisonId)
    $cmd.Parameters.AddWithValue("@ctype", $ComponentType)
    $cmd.Parameters.AddWithValue("@json", $jsonContent)
    try {
        $cmd.ExecuteNonQuery() | Out-Null
        Write-Host "JSON diff for $ComponentType inserted into comparison_component." -ForegroundColor Green
    } catch {
        Write-Host "Failed to insert component diff: $_" -ForegroundColor Red
    }
}

Export-ModuleMember -Function Open-MySqlConnection, Close-MySqlConnection, Add-PCAsset, Get-PCId, Add-ComparisonResult, Add-ComparisonComponent
