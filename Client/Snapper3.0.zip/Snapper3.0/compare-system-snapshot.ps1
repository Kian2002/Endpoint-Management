Import-Module "$PSScriptRoot\Modules\config.ps1"
Import-Module "$PSScriptRoot\Modules\database_module.psm1"

# Open the connection using the secure string
Open-MySqlConnection -ConnectionString $Global:MySQLConnectionString

# Directory containing the snapshots
$Directory = "$PSScriptRoot\info"
$Folders = Get-ChildItem $Directory -Directory

if ($Folders.Count -lt 2) {
    Write-Host ""
    Write-Host "Error: There must be at least two folders in $Directory for comparison." -ForegroundColor Red
    exit
}

#$folder1 = $Folders[1].FullName
#$folder2 = $Folders[0].FullName
#$PC1 = $Folders[1].Name
#$PC2 = $Folders[0].Name


## New Block to get folders dynamically

# Dynamically detect PC name
$pcName = $env:COMPUTERNAME

# Look for folders matching PC and PC_baseline
$baselineFolder = Get-ChildItem "$PSScriptRoot\info" -Directory | Where-Object { $_.Name -eq "${pcName}_baseline" }
$currentFolder  = Get-ChildItem "$PSScriptRoot\info" -Directory | Where-Object { $_.Name -eq $pcName }

if (-not $baselineFolder) {
    Write-Host "Error: Baseline folder '${pcName}_baseline' not found." -ForegroundColor Red
    exit
}

if (-not $currentFolder) {
    Write-Host "Error: Snapshot folder '$pcName' not found." -ForegroundColor Red
    exit
}

$folder1 = $currentFolder.FullName   # current
$folder2 = $baselineFolder.FullName  # baseline
$PC1 = $currentFolder.Name
$PC2 = $baselineFolder.Name

Write-Host ""
Write-Host "Found baseline folder: $PC2" -ForegroundColor Yellow
Write-Host "Found current snapshot: $PC1" -ForegroundColor Yellow



Add-PCAsset -AssetTag $PC1
$pc_id = Get-PCId -AssetTag $PC1


# Find latest write time of any file inside the folder
function Get-SnapshotTimestamp {
    param (
        [string]$folderPath
    )

    $latestFile = Get-ChildItem -Path $folderPath -File | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($latestFile) {
        return $latestFile.LastWriteTime
    } else {
        return $null
    }
}
$snapshot_before = Get-SnapshotTimestamp -folderPath $folder2
$snapshot_after  = Get-SnapshotTimestamp -folderPath $folder1

Write-Host ""
Write-Host "========== System Snapshot Comparison ==========" -ForegroundColor Cyan
Write-Host ""
Write-Host "Baseline snapshot time (before): $snapshot_before" -ForegroundColor Cyan
Write-Host "New snapshot time (after): $snapshot_after" -ForegroundColor Cyan

$comparison_id = Add-ComparisonResult -PCId $pc_id -SnapshotBefore $snapshot_before -SnapshotAfter $snapshot_after -ComparedBy "junaid"
Write-Host ""
Write-Host "Comparison ID created: $comparison_id" -ForegroundColor Green
Write-Host ""
Write-Host "Comparing system snapshots: $PC1 vs $PC2" -ForegroundColor Cyan

$files1 = Get-ChildItem $folder1 -File
$files2 = Get-ChildItem $folder2 -File

####### Functions Section ##########

# --- Comparison Functions Section ---
$comparisonSummary = @()


function Write-Step {
    param (
        [string]$Message
    )
    Write-Host ""
    Write-Host $Message -ForegroundColor Cyan
}

function Compare-Softwares {
    param (
        [string]$File1Path,
        [string]$File2Path, 
        [string]$PC2
    )
    Write-Step "Comparing software list..."
    $component = "software"
    $errorMsg = $null
    try {
        $Differences = Compare-Object -ReferenceObject (Import-Clixml $File1Path) -DifferenceObject (Import-Clixml $File2Path) -Property DisplayName, DisplayVersion, Publisher -IncludeEqual -PassThru
        $OutputFolder = "$PSScriptRoot\output\$PC2"
        if (-not (Test-Path $OutputFolder)) {
            Write-Host "Creating output folder: $OutputFolder" -ForegroundColor Cyan
            New-Item -ItemType Directory -Path $OutputFolder | Out-Null
        }
        Write-Host "Storing differences in $OutputFolder" -ForegroundColor Cyan
        $Differences | Out-File "$OutputFolder\softwares.txt"
        $Differences | ConvertTo-Json | Out-File "$OutputFolder\softwares.json"
        $comparison_id = $comparison_id[-1]
        Add-ComparisonComponent -ComparisonId $comparison_id -ComponentType $component -JsonFilePath "$OutputFolder\softwares.json" | Out-Null
    }
    catch {
        $errorMsg = $_.Exception.Message
        Write-Host "Error comparing $component : $errorMsg" -ForegroundColor Red
    }
    $comparisonSummary += [PSCustomObject]@{ Component = $component; Error = $errorMsg }
}

function Compare-Services {
    param (
        [string]$File1Path,
        [string]$File2Path,
        [string]$PC2
    )
    Write-Step "Comparing services..."
    $component = "services"
    $errorMsg = $null
    try {
        $Differences = Compare-Object -ReferenceObject (Import-Clixml $File1Path) -DifferenceObject (Import-Clixml $File2Path) -Property DisplayName, Status -IncludeEqual -PassThru
        $OutputFolder = "$PSScriptRoot\output\$PC2"
        if (-not (Test-Path $OutputFolder)) {
            Write-Host "Creating output folder: $OutputFolder" -ForegroundColor Cyan
            New-Item -ItemType Directory -Path $OutputFolder | Out-Null
        }
        Write-Host "Storing differences in $OutputFolder" -ForegroundColor Cyan
        $Differences | Out-File "$OutputFolder\Services.txt"
        $Differences | ConvertTo-Json | Out-File "$OutputFolder\Services.json"
        $comparison_id = $comparison_id[-1]
        Add-ComparisonComponent -ComparisonId $comparison_id -ComponentType $component -JsonFilePath "$OutputFolder\Services.json" | Out-Null
    }
    catch {
        $errorMsg = $_.Exception.Message
        Write-Host "Error comparing $component : $errorMsg" -ForegroundColor Red
    }
    $comparisonSummary += [PSCustomObject]@{ Component = $component; Error = $errorMsg }
}

function Compare-Processes {
    param (
        [string]$File1Path,
        [string]$File2Path,
        [string]$PC2
    )
    Write-Step "Comparing processes..."
    $component = "processes"
    $errorMsg = $null
    try {
        $Differences = Compare-Object -ReferenceObject (Import-Clixml $File1Path) -DifferenceObject (Import-Clixml $File2Path) -Property Name, Path -IncludeEqual -PassThru
        $OutputFolder = "$PSScriptRoot\output\$PC2"
        if (-not (Test-Path $OutputFolder)) {
            Write-Host "Creating output folder: $OutputFolder" -ForegroundColor Cyan
            New-Item -ItemType Directory -Path $OutputFolder | Out-Null
        }
        Write-Host "Storing differences in $OutputFolder" -ForegroundColor Cyan
        $Differences | Out-File "$OutputFolder\Processes.txt"
        $Differences | ConvertTo-Json -Depth 5 | Out-File "$OutputFolder\Processes.json"
        $comparison_id = $comparison_id[-1]
        Add-ComparisonComponent -ComparisonId $comparison_id -ComponentType $component -JsonFilePath "$OutputFolder\Processes.json" | Out-Null
    }
    catch {
        $errorMsg = $_.Exception.Message
        Write-Host "Error comparing $component : $errorMsg" -ForegroundColor Red
    }
    $comparisonSummary += [PSCustomObject]@{ Component = $component; Error = $errorMsg }
}

function Compare-EnvironmentVariables {
    param (
        [string]$File1Path,
        [string]$File2Path,
        [string]$PC2
    )
    Write-Step "Comparing environment variables..."
    $component = "environmentVariables"
    $errorMsg = $null
    try {
        $Differences = Compare-Object -ReferenceObject (Import-Clixml $File1Path) -DifferenceObject (Import-Clixml $File2Path) -Property Name, Value -IncludeEqual -PassThru
        $OutputFolder = "$PSScriptRoot\output\$PC2"
        if (-not (Test-Path $OutputFolder)) {
            Write-Host "Creating output folder: $OutputFolder" -ForegroundColor Cyan
            New-Item -ItemType Directory -Path $OutputFolder | Out-Null
        }
        Write-Host "Storing differences in $OutputFolder" -ForegroundColor Cyan
        $Differences | Out-File "$OutputFolder\EnvironmentVariables.txt"
        $Differences | ConvertTo-Json -Depth 5 | Out-File "$OutputFolder\EnvironmentVariables.json"
        $comparison_id = $comparison_id[-1]
        Add-ComparisonComponent -ComparisonId $comparison_id -ComponentType $component -JsonFilePath "$OutputFolder\EnvironmentVariables.json" | Out-Null
    }
    catch {
        $errorMsg = $_.Exception.Message
        Write-Host "Error comparing $component : $errorMsg" -ForegroundColor Red
    }
    $comparisonSummary += [PSCustomObject]@{ Component = $component; Error = $errorMsg }
}

function Compare-printers {
    param (
        [string]$File1Path,
        [string]$File2Path,
        [string]$PC2
    )
    Write-Step "Comparing printers..."
    $component = "printers"
    $errorMsg = $null
    try {
        $Differences = Compare-Object -ReferenceObject (Import-Clixml $File1Path) -DifferenceObject (Import-Clixml $File2Path) -Property Name, PortName, PrinterStatus -IncludeEqual -PassThru
        $OutputFolder = "$PSScriptRoot\output\$PC2"
        if (-not (Test-Path $OutputFolder)) {
            Write-Host "Creating output folder: $OutputFolder" -ForegroundColor Cyan
            New-Item -ItemType Directory -Path $OutputFolder | Out-Null
        }
        Write-Host "Storing differences in $OutputFolder" -ForegroundColor Cyan
        $Differences | Out-File "$OutputFolder\printers.txt"
        $Differences | ConvertTo-Json | Out-File "$OutputFolder\printers.json"
        $comparison_id = $comparison_id[-1]
        Add-ComparisonComponent -ComparisonId $comparison_id -ComponentType $component -JsonFilePath "$OutputFolder\printers.json" | Out-Null
    }
    catch {
        $errorMsg = $_.Exception.Message
        Write-Host "Error comparing $component : $errorMsg" -ForegroundColor Red
    }
    $comparisonSummary += [PSCustomObject]@{ Component = $component; Error = $errorMsg }
}

function Compare-Objects-Generic{
    param (
        [string]$File1Path,
        [string]$File2Path,
        [string]$PC2,
        [string]$ComponentType
    )
    Write-Step "Comparing $ComponentType..."
    $errorMsg = $null
    try {
        $Differences = Compare-Object -ReferenceObject (Import-Clixml $File1Path) -DifferenceObject (Import-Clixml $File2Path) -IncludeEqual -PassThru
        $OutputFolder = "$PSScriptRoot\output\$PC2"
        if (-not (Test-Path $OutputFolder)) {
            Write-Host "Creating output folder: $OutputFolder" -ForegroundColor Cyan
            New-Item -ItemType Directory -Path $OutputFolder | Out-Null
        }
        Write-Host "Storing differences in $OutputFolder" -ForegroundColor Cyan
        $Differences | Out-File "$OutputFolder\$ComponentType.txt"
        $Differences | ConvertTo-Json | Out-File "$OutputFolder\$ComponentType.json"
        $comparison_id = $comparison_id[-1]
        Add-ComparisonComponent -ComparisonId $comparison_id -ComponentType "$ComponentType" -JsonFilePath "$OutputFolder\$ComponentType.json" | Out-Null
    }
    catch {
        $errorMsg = $_.Exception.Message
        Write-Host "Error comparing $ComponentType : $errorMsg" -ForegroundColor Red
    }
    $comparisonSummary += [PSCustomObject]@{ Component = $ComponentType; Error = $errorMsg }
}

function Compare-WindowsUpdates {
    param (
        [string]$File1Path,
        [string]$File2Path,
        [string]$PC2
    )
    Write-Step "Comparing Windows updates..."
    $component = "updates"
    $errorMsg = $null
    try {
        $Differences = Compare-Object -ReferenceObject (Import-Clixml $File1Path) -DifferenceObject (Import-Clixml $File2Path) -IncludeEqual -PassThru
        $OutputFolder = "$PSScriptRoot\output\$PC2"
        if (-not (Test-Path $OutputFolder)) {
            Write-Host "Creating output folder: $OutputFolder" -ForegroundColor Cyan
            New-Item -ItemType Directory -Path $OutputFolder | Out-Null
        }
        Write-Host "Storing differences in $OutputFolder" -ForegroundColor Cyan
        $Differences | Out-File "$OutputFolder\updates.txt"
        $Differences | ConvertTo-Json | Out-File "$OutputFolder\updates.json"
        $comparison_id = $comparison_id[-1]
        Add-ComparisonComponent -ComparisonId $comparison_id -ComponentType $component -JsonFilePath "$OutputFolder\updates.json" | Out-Null
    }
    catch {
        $errorMsg = $_.Exception.Message
        Write-Host "Error comparing $component : $errorMsg" -ForegroundColor Red
    }
    $comparisonSummary += [PSCustomObject]@{ Component = $component; Error = $errorMsg }
}

function Compare-networkDrive {
    param (
        [string]$File1Path,
        [string]$File2Path,
        [string]$PC2
    )
    Write-Step "Comparing network drives..."
    $component = "networkDrives"
    $errorMsg = $null
    try {
        $Differences = Compare-Object -ReferenceObject (Import-Clixml $File1Path) -DifferenceObject (Import-Clixml $File2Path) -Property Name, DisplayRoot -IncludeEqual -PassThru
        $OutputFolder = "$PSScriptRoot\output\$PC2"
        if (-not (Test-Path $OutputFolder)) {
            Write-Host "Creating output folder: $OutputFolder" -ForegroundColor Cyan
            New-Item -ItemType Directory -Path $OutputFolder | Out-Null
        }
        Write-Host "Storing differences in $OutputFolder" -ForegroundColor Cyan
        $Differences | Out-File "$OutputFolder\networkDrives.txt"
        $Differences | ConvertTo-Json | Out-File "$OutputFolder\networkDrives.json"
        $comparison_id = $comparison_id[-1]
        Add-ComparisonComponent -ComparisonId $comparison_id -ComponentType $component -JsonFilePath "$OutputFolder\networkDrives.json" | Out-Null
    }
    catch {
        $errorMsg = $_.Exception.Message
        Write-Host "Error comparing $component : $errorMsg" -ForegroundColor Red
    }
    $comparisonSummary += [PSCustomObject]@{ Component = $component; Error = $errorMsg }
}

function Compare-SystemInfo {
    param (
        [string]$File1Path,
        [string]$File2Path,
        [string]$PC2,
        [string]$ComponentType
    )
    Write-Step "Comparing system info..."
    $errorMsg = $null
    try {
        $comp1 = Import-Clixml $File1Path
        $comp2 = Import-Clixml $File2Path
        $comp1Props = $comp1.PSObject.Properties | Select-Object Name, Value
        $comp2Props = $comp2.PSObject.Properties | Select-Object Name, Value
        $Differences = Compare-Object -ReferenceObject $comp1Props -DifferenceObject $comp2Props -Property Name, Value -IncludeEqual -PassThru
        $OutputFolder = "$PSScriptRoot\output\$PC2"
        if (-not (Test-Path $OutputFolder)) {
            Write-Host "Creating output folder: $OutputFolder" -ForegroundColor Cyan
            New-Item -ItemType Directory -Path $OutputFolder | Out-Null
        }
        Write-Host "Storing differences in $OutputFolder" -ForegroundColor Cyan
        $Differences | Out-File "$OutputFolder\$ComponentType.txt"
        $Differences | ConvertTo-Json -Depth 5 | Out-File "$OutputFolder\$ComponentType.json"
        $comparison_id = $comparison_id[-1]
        Add-ComparisonComponent -ComparisonId $comparison_id -ComponentType "$ComponentType" -JsonFilePath "$OutputFolder\$ComponentType.json" | Out-Null
    }
    catch {
        $errorMsg = $_.Exception.Message
        Write-Host "Error comparing $ComponentType : $errorMsg" -ForegroundColor Red
    }
    $comparisonSummary += [PSCustomObject]@{ Component = $ComponentType; Error = $errorMsg }
}

function Compare-NetworkConfig {
    param (
        [string]$File1Path,
        [string]$File2Path,
        [string]$PC2,
        [string]$ComponentType
    )
    Write-Step "Comparing network configuration..."
    $errorMsg = $null
    try {
        $net1 = Import-Clixml $File1Path
        $net2 = Import-Clixml $File2Path
        $Differences = Compare-Object -ReferenceObject $net1 -DifferenceObject $net2 `
            -Property InterfaceAlias, IPv4Address, IPv6Address, IPv4Gateway, IPv6Gateway, DNSServers `
            -IncludeEqual -PassThru
        $OutputFolder = "$PSScriptRoot\output\$PC2"
        if (-not (Test-Path $OutputFolder)) {
            Write-Host "Creating output folder: $OutputFolder" -ForegroundColor Cyan
            New-Item -ItemType Directory -Path $OutputFolder | Out-Null
        }
        Write-Host "Storing differences in $OutputFolder" -ForegroundColor Cyan
        $Differences | Out-File "$OutputFolder\$ComponentType.txt"
        $Differences | ConvertTo-Json -Depth 5 | Out-File "$OutputFolder\$ComponentType.json"
        $comparison_id = $comparison_id[-1]
        Add-ComparisonComponent -ComparisonId $comparison_id -ComponentType "$ComponentType" -JsonFilePath "$OutputFolder\$ComponentType.json" | Out-Null
    }
    catch {
        $errorMsg = $_.Exception.Message
        Write-Host "Error comparing $ComponentType : $errorMsg" -ForegroundColor Red
    }
    $comparisonSummary += [PSCustomObject]@{ Component = $ComponentType; Error = $errorMsg }
}

function Compare-StartupPrograms {
    param (
        [string]$File1Path,
        [string]$File2Path,
        [string]$PC2
    )
    Write-Step "Comparing startup programs..."
    $component = "startupPrograms"
    $errorMsg = $null
    try {
        $Differences = Compare-Object -ReferenceObject (Import-Clixml $File1Path) `
                                      -DifferenceObject (Import-Clixml $File2Path) `
                                      -Property Name, Command -IncludeEqual -PassThru
        $OutputFolder = "$PSScriptRoot\output\$PC2"
        if (-not (Test-Path $OutputFolder)) {
            Write-Host "Creating output folder: $OutputFolder" -ForegroundColor Cyan
            New-Item -ItemType Directory -Path $OutputFolder | Out-Null
        }
        Write-Host "Storing differences in $OutputFolder" -ForegroundColor Cyan
        $Differences | Out-File "$OutputFolder\startupPrograms.txt"
        $Differences | ConvertTo-Json | Out-File "$OutputFolder\startupPrograms.json"
        $comparison_id = $comparison_id[-1]
        Add-ComparisonComponent -ComparisonId $comparison_id -ComponentType $component -JsonFilePath "$OutputFolder\startupPrograms.json" | Out-Null
    }
    catch {
        $errorMsg = $_.Exception.Message
        Write-Host "Error comparing $component : $errorMsg" -ForegroundColor Red
    }
    $comparisonSummary += [PSCustomObject]@{ Component = $component; Error = $errorMsg }
}

function Compare-Drivers {
    param (
        [string]$File1Path,
        [string]$File2Path,
        [string]$PC2
    )
    Write-Step "Comparing drivers..."
    $component = "drivers"
    $errorMsg = $null
    try {
        $Differences = Compare-Object -ReferenceObject (Import-Clixml $File1Path) `
            -DifferenceObject (Import-Clixml $File2Path) `
            -Property Name, Manufacturer, DriverVersion, DriverDate `
            -IncludeEqual -PassThru
        $OutputFolder = "$PSScriptRoot\output\$PC2"
        if (-not (Test-Path $OutputFolder)) {
            Write-Host "Creating output folder: $OutputFolder" -ForegroundColor Cyan
            New-Item -ItemType Directory -Path $OutputFolder | Out-Null
        }
        Write-Host "Storing differences in $OutputFolder" -ForegroundColor Cyan
        $Differences | Format-Table -AutoSize | Out-File "$OutputFolder\drivers.txt"
        $Differences | ConvertTo-Json -Depth 5 | Out-File "$OutputFolder\drivers.json"
        $comparison_id = $comparison_id[-1]
        Add-ComparisonComponent -ComparisonId $comparison_id -ComponentType $component -JsonFilePath "$OutputFolder\drivers.json" | Out-Null
    }
    catch {
        $errorMsg = $_.Exception.Message
        Write-Host "Error comparing $component : $errorMsg" -ForegroundColor Red
    }
    $comparisonSummary += [PSCustomObject]@{ Component = $component; Error = $errorMsg }
}

##### END OF Functions ######



foreach ($file1 in $files1) {
    $file2 = $files2 | Where-Object { $_.Name -eq $file1.Name }
    if ($file2) {
        Write-Host ""
        Write-Host "Comparing $($file1.Name)..." -ForegroundColor Cyan

        if ($file1.Name -eq "softwareList.xml") {
            Compare-Softwares -File1Path $file1.FullName -File2Path $file2.FullName -PC2 $PC2
        }
        elseif ($file1.Name -eq "services.xml") {
            Compare-Services -File1Path $file1.FullName -File2Path $file2.FullName -PC2 $PC2
        }
        elseif ($file1.Name -eq "process.xml") {
            Compare-Processes -File1Path $file1.FullName -File2Path $file2.FullName -PC2 $PC2
        }
        elseif ($file1.Name -eq "environmentVariables.xml") {
            Compare-EnvironmentVariables -File1Path $file1.FullName -File2Path $file2.FullName -PC2 $PC2
        }
        elseif ($file1.Name -eq "printers.xml") {
            Compare-printers -File1Path $file1.FullName -File2Path $file2.FullName -PC2 $PC2
        }
        elseif ($file1.Name -eq "networkDrive.xml") {
            Compare-networkDrive -File1Path $file1.FullName -File2Path $file2.FullName -PC2 $PC2
        }
        elseif ($file1.Name -eq "systeminfo.xml") {
            Compare-SystemInfo -File1Path $file1.FullName -File2Path $file2.FullName -PC2 $PC2 -ComponentType "systeminfo"
        }
        elseif ($file1.Name -eq "ipconfig.xml") {
            Compare-NetworkConfig -File1Path $file1.FullName -File2Path $file2.FullName -PC2 $PC2 -ComponentType "ipConfig"
        }
        elseif ($file1.Name -eq "userAccounts.xml") {
            Compare-Objects-Generic -File1Path $file1.FullName -File2Path $file2.FullName -PC2 $PC2 -ComponentType "accounts"
        }
        elseif ($file1.Name -eq "windowsUpdates.xml") {
            Compare-WindowsUpdates -File1Path $file1.FullName -File2Path $file2.FullName -PC2 $PC2
        }
        elseif ($file1.Name -eq "startupPrograms.xml") {
            Compare-StartupPrograms -File1Path $file1.FullName -File2Path $file2.FullName -PC2 $PC2
        }
        elseif ($file1.Name -eq "drivers.xml") {
            Compare-Drivers -File1Path $file1.FullName -File2Path $file2.FullName -PC2 $PC2
        }
        else {
            Write-Host "Skipping $($file1.Name)" -ForegroundColor Yellow
        }
    }
    else {
        Write-Host ""
        Write-Host "File not found in $PC2 : $($file1.Name)" -ForegroundColor Yellow
    }
}

Close-MySqlConnection
Write-Host ""
Write-Host "========== Comparison Summary ==========" -ForegroundColor Cyan
foreach ($entry in $comparisonSummary) {
    if ($entry.Error) {
        Write-Host "$($entry.Component): Error - $($entry.Error)" -ForegroundColor Red
    } else {
        Write-Host "$($entry.Component): Completed" -ForegroundColor Green
    }
}