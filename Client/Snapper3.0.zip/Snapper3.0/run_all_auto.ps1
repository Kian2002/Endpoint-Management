param (
    [switch]$AutoMode = $true,
    [switch]$IsBaseline = $false,
    [switch]$CompareAfter = $true
)

Write-Host "Starting System Snapshot and Comparison Workflow..." -ForegroundColor Cyan

# Set default values
$computerName = $env:COMPUTERNAME
$baselineFolderName = "${computerName}_baseline"
$env:SNAPSHOT_FOLDER = if ($IsBaseline) { $baselineFolderName } else { $computerName }

Write-Host $("Snapshot will be saved under: info\$($env:SNAPSHOT_FOLDER)") -ForegroundColor Cyan

# Define paths
$scriptRoot = $PSScriptRoot
$collectScript = Join-Path $scriptRoot "collect-system-snapshot.ps1"
$compareScript = Join-Path $scriptRoot "compare-system-snapshot.ps1"

# Run snapshot collection
if (Test-Path $collectScript) {
    Write-Host "`nRunning system snapshot collection..." -ForegroundColor Green
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File $collectScript
    Write-Host "`nSnapshot collection completed!" -ForegroundColor Green
} else {
    Write-Host "Snapshot script not found at $collectScript." -ForegroundColor Red
    exit
}

# If running baseline mode and CompareAfter is enabled, collect second snapshot
if ($IsBaseline -and $CompareAfter) {
    $env:SNAPSHOT_FOLDER = $computerName
    Write-Host "`nRunning second snapshot for comparison..." -ForegroundColor Cyan
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File $collectScript
    Write-Host "`nSecond snapshot collection completed!" -ForegroundColor Green
}

# Run comparison if allowed
if ($CompareAfter) {
    if (Test-Path $compareScript) {
        Write-Host "`nRunning comparison script..." -ForegroundColor Cyan
        powershell.exe -NoProfile -ExecutionPolicy Bypass -File $compareScript
        Write-Host "`nComparison completed and database updated!" -ForegroundColor Green
    } else {
        Write-Host "Comparison script not found at $compareScript." -ForegroundColor Red
    }
} else {
    Write-Host "Skipped running comparison." -ForegroundColor Yellow
}

Write-Host "`nWorkflow finished!" -ForegroundColor Cyan
