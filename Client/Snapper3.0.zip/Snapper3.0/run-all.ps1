Write-Host "Starting System Snapshot and Comparison Workflow..." -ForegroundColor Cyan

# Get script root
$scriptRoot = $PSScriptRoot

# Ask whether user wants to collect baseline or regular snapshot
$createBaseline = $false
$computerName = $env:COMPUTERNAME
$baselineFolderName = "${computerName}_baseline"
$env:SNAPSHOT_FOLDER = $computerName  # default

$folderPrompt = Read-Host "Do you want to collect a baseline snapshot? (Y/N)"
if ($folderPrompt -eq "Y" -or $folderPrompt -eq "y") {
    $createBaseline = $true
    $env:SNAPSHOT_FOLDER = $baselineFolderName
    Write-Host "Baseline mode selected. Snapshot will be saved under: info\$baselineFolderName" -ForegroundColor Yellow
} else {
    Write-Host "Regular snapshot will be saved under: info\$($env:SNAPSHOT_FOLDER)" -ForegroundColor Cyan
}

# Define paths
$collectScript = Join-Path $scriptRoot "collect-system-snapshot.ps1"
$compareScript = Join-Path $scriptRoot "compare-system-snapshot.ps1"

# Run snapshot collection in a new PowerShell process
if (Test-Path $collectScript) {
    Write-Host "`nRunning system snapshot collection..." -ForegroundColor Green
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File $collectScript
    Write-Host "`nSnapshot collection completed!" -ForegroundColor Green
} else {
    Write-Host "Snapshot script not found at $collectScript." -ForegroundColor Red
    exit
}

# If baseline was created, prompt to take a second snapshot to compare
if ($createBaseline) {
    $secondPrompt = Read-Host "`nWould you like to collect a second snapshot for comparison now? (Y/N)"
    if ($secondPrompt -eq "Y" -or $secondPrompt -eq "y") {
        $env:SNAPSHOT_FOLDER = $computerName  # now take the current state
        Write-Host "`nRunning second snapshot for comparison..." -ForegroundColor Cyan
        powershell.exe -NoProfile -ExecutionPolicy Bypass -File $collectScript
        Write-Host "`nSecond snapshot collection completed!" -ForegroundColor Green
    }
}

# Prompt to run comparison
$runCompare = Read-Host "`nDo you want to run the comparison now and update the database? (Y/N)"

if ($runCompare -eq "Y" -or $runCompare -eq "y") {
    if (Test-Path $compareScript) {
        Write-Host "`nRunning comparison script..." -ForegroundColor Cyan
        powershell.exe -NoProfile -ExecutionPolicy Bypass -File $compareScript
        Write-Host "`nComparison completed and database updated!" -ForegroundColor Green
    } else {
        Write-Host "Comparison script not found at $compareScript." -ForegroundColor Red
    }
} else {
    Write-Host "Skipped running comparison. You can run it manually later." -ForegroundColor Yellow
}

Write-Host "`nWorkflow finished!" -ForegroundColor Cyan
