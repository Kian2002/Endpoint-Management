# 📦 Snapper Client Setup Guide

## Overview

Snapper is a lightweight PowerShell client designed to capture detailed system snapshots, compare them to a baseline, and log the differences in a centralized MySQL database. This tool is ideal for IT technicians and sysadmins who need to track and audit system-level changes across endpoints.

---

## 🔧 How It Works

1. **System Snapshot** — Captures system info (software, services, drivers, etc.) and stores it in `.xml` format under `info/`.
2. **Comparison** — Compares new snapshot with baseline and generates a diff.
3. **Database Update** — Saves the diff in a remote MySQL database (e.g., AWS RDS).
4. **Password Handling** — Secure hybrid prompt model. On first run, prompts for password and stores it securely.

---

## 🗂️ Folder Structure

```
Snapper/
├── Modules/
│   ├── config.ps1                # Handles DB connection setup
│   └── database_module.psm1      # Contains database functions
├── Connectors/
│   └── MySql.Data.dll            # MySQL .NET Connector DLL
├── info/                         # Stores snapshot folders per PC
├── output/                       # Stores comparison results (TXT & JSON)
├── collect-system-snapshot.ps1   # Script to collect system info
├── compare-system-snapshot.ps1   # Script to compare snapshots and store result
├── setup.bat                     # Launches the full workflow (collection + comparison)
└── README.md                     # This file
```

---

## 🚀 Quick Start

### ✅ Step-by-step

1. **Double-click `setup.bat`** or run from terminal:
   ```shell
   setup.bat
   ```

2. **Choose Baseline or Regular Snapshot:**
   - Press `Y` if setting up a baseline (first-time snapshot on a PC).
   - Otherwise, press `N` to record a new/current snapshot.

3. **Follow prompt to run comparison.**
   - Compares new snapshot with baseline (e.g., `baseline/` vs `INTEL/`)
   - Diff is exported and pushed to database.

---

## 🔐 Security: Password Management

- MySQL password is **never stored in plain text**.
- First-time run on a PC will prompt for the password.
- Password is saved in encrypted format (`db_pwd.sec`) using PowerShell's `ConvertFrom-SecureString`.

---

## 📋 Requirements

- Windows (PowerShell 5.1+ recommended)
- .NET Framework 4.7.2+
- MySQL Server (remote or local)
- MySQL .NET Connector DLL (`MySql.Data.dll`)

---

## 🧩 Troubleshooting

- **Password mismatch?** → You’ll be re-prompted and it will update the saved `.sec` file.
- **DLL errors?** → Ensure `MySql.Data.dll` is present in `Connectors/`.
- **Comparison fails?** → Make sure you have **two folders** in `info/`: baseline and new snapshot.

---

## 📬 Contact

For help or contributions, contact: **junaid.asghar@yourdomain.com**