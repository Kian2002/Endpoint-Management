# =========================
# config.ps1 - Local configuration
# =========================

$securePath = Join-Path -Path $PSScriptRoot -ChildPath "..\db_pwd.sec"

# Check if password file exists
if (Test-Path $securePath) {
    try {
        $securePwd = Get-Content $securePath | ConvertTo-SecureString
        $Bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePwd)
        $plainPwd = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($Bstr)
        [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($Bstr)
        Write-Host "MySQL password loaded from secure file." -ForegroundColor Green
    } catch {
        Write-Host "Failed to read secure password file. You will be prompted." -ForegroundColor Yellow
        $plainPwd = Read-Host -AsSecureString "Enter MySQL password (secure)"
        $plainPwd | ConvertFrom-SecureString | Set-Content $securePath
        $Bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($plainPwd)
        $plainPwd = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($Bstr)
        [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($Bstr)
        Write-Host "Password saved for future runs." -ForegroundColor Green
    }
} else {
    Write-Host "MySQL password file not found. Prompting for password..." -ForegroundColor Yellow
    $plainPwdSecure = Read-Host -AsSecureString "Enter MySQL password (secure)"
    $plainPwdSecure | ConvertFrom-SecureString | Set-Content $securePath
    $Bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($plainPwdSecure)
    $plainPwd = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($Bstr)
    [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($Bstr)
    Write-Host "Password securely saved for future runs." -ForegroundColor Green
}

# Build connection string using plain password
$Global:MySQLConnectionString = "server=endpoint-snapshot-db.c9kgcu6yi7f2.us-east-2.rds.amazonaws.com;port=3306;uid=admin;pwd=$plainPwd;database=snapshot;"
